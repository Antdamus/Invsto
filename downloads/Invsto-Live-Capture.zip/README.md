# Invsto Live Capture (1.3.0)

This helper copies visible eBay Stream Manager auction and payment evidence into Invsto. It can also prepare a new auction form from an inventory item you explicitly queue. It never clicks Create listing or Start, bids, charges buyers, or cancels eBay orders.

## Dedicated computer setup

1. Download **Invsto Live Capture** from Live Sales → Capture setup and connection help. Extract the ZIP into a permanent folder.
2. In Microsoft Edge open **Extensions → Manage extensions**. Enable **Developer mode**, choose **Load unpacked**, then select the extracted folder containing `manifest.json`. Chrome supports the same steps.
3. Open the event's eBay Stream Manager dashboard and click **Start Invsto capture** in the bottom-left corner. The helper reads the saved date, timezone and title from Event information in a temporary background tab, then closes that tab. Your broadcasting tab stays on Stream Manager. It does not update the eBay event. Invsto opens automatically with that exact event and original date. Sign in if needed.
4. Choose the **First seller**, optionally check **Additional sellers**, and tap **Start show**. No store, URL, title or starting auction number is required. Invsto creates and links the session, then returns to the eBay capture tab. Repeating capture for the same unfinished event reconnects to its existing session and keeps its sellers. A completed show cannot be reopened by capture.
5. Keep the automatically opened **capture receiver** signed in and open. Observations are buffered while seller setup is pending and saved after the show is linked. The helper selects Activity → All and Sold, and scrolls those lists. Before the first sale, it watches All listings until Sold becomes available. Use another window if you need to operate the broadcast.
6. Keep the computer awake. Allow these two pages to stay active in the browser's sleeping-tabs / memory-saver settings. The receiver can be behind the Stream Manager window; the Stream Manager tab may remain in the background while its elapsed clock continues updating. If the clock stops, bring it forward. Click Start again after reloading it.
7. On each phone, sign in to Invsto, open Live Sales, and select the same show. Wait for **Connected - auctions update automatically**, then choose **Scan sold item** on a paid auction. Scan the inventory barcode/QR, review the manifest, and **Close paid bag**. Printing is optional afterward and supports your existing print stations.

Start capture before the first auction when possible. A finished eBay event can backfill the Activity and Sold history that eBay still exposes. The original saved event date is the show start; the import time stays separate. Recovered history defaults to the first seller selected, because eBay does not identify your on-air employees. Admins can use Change seller on one sale, select several sales for a correction, or correct all earlier sales under Change seller. Each correction also updates its bag. Set the on-air seller during a running show for new auctions.

## Payment and recovery behavior

- **Won** means waiting for payment. Only explicit Paid evidence, an exact official order match, or an audited staff verification enables a scan.
- A failure, cancellation or refund stops new scans. Already scanned contents remain reserved until someone checks the physical bag. **Resolve locally and release bag contents** requires that check and a written reason. Cancel or refund the actual order separately in eBay when appropriate.
- A rerun is a new attempt. Replayed Paid badges cannot pay a later rerun. If two attempts cannot be distinguished, use Payment / bag review and verify the actual transaction in eBay.
- Unknown notifications pause automatic scanning. Review the notification, attach it to the affected auction if identifiable, and then verify that auction's payment or resolve it. Do not dismiss an unexplained payment failure.
- One scanner claims a bag at a time. An admin can release a stuck claim. Printing alone does not close a bag.
- If capture stops or becomes stale, scans pause. After verifying the current transaction directly on eBay, staff may record payment evidence for a two-minute manual scanning window.
- Unsent observations remain in the extension's local outbox until Invsto acknowledges a successful database save. Reconnect the receiver before ending the show. Do not uninstall the extension or clear browser storage while it reports pending observations.
- Existing eBay order imports reconcile exact unique matches and later cancellations/refunds, even after closing a bag. Packed items need the existing order/return correction workflow; the queue cannot silently put shipped stock back.

## After the broadcast

The helper detects eBay's explicit **Event ended** control and moves Invsto into **Post-show review**. A frozen clock or zero viewers never ends a show. With an older helper or if capture is stopped, use **Stream ended? Start bag review** in Invsto.

The inventory session stays open. Finish every paid bag, scan missing items, and use **Reopen to check / add items** to correct a closed bag. Payment failures, waiting payments and unmatched notifications still require review. A bag already in packing must be checked in Pending Orders.

Compare the complete auction list against the final eBay orders, including any sales capture missed. When all recorded paid bags are closed and outstanding payment/notification issues are resolved, confirm the physical bag and payment checkboxes and choose **Close reviewed session**. Ending the broadcast never automatically closes bags, cancels orders or releases inventory.

## Totals and timing

Totals include only paid, closed bags. Above minimum = auction price − captured inventory minimum prices. Estimated profit also subtracts captured item costs and the admin's explicit fee/shipping estimates per auction. Unknown values stay missing; they are excluded from the displayed partial total. These are USD estimates, not final payouts, tax accounting or realized profit after returns.

eBay's Activity clock has minute precision. Invsto combines it with the event's saved date and the capture browser timezone, including overnight sales. It uses a single-day window from two hours before the scheduled start through 22 hours afterward; multi-day broadcasts cannot be uniquely dated from a clock alone. Ambiguous or nonexistent daylight-saving times remain unverified. Capture computers for one event must use the same timezone to avoid interpreting the same clock differently. Official order timestamps fill missing sale times when a unique order matches; order matching uses a date range, not an exact timestamp. The saved scheduled start is not proof of the exact second the broadcast began. Stream offsets are approximate and can be unavailable; they are not exact replay timestamps. Capture and phone refresh target a few seconds while connected, but browser rendering, long history sweeps and network delays can increase latency. Treat this first release as a supervised pilot and compare it with eBay during a real show.

## Updating

Replace the extracted folder's files with the new download, click Reload on the extension card, and reload both the receiver and Stream Manager. Saved outbox data remains in that extension's browser profile when reloading the same installation.

## Data access

The extension runs only on eBay host-event pages and Invsto Live Sales. It stores the capture outbox/health, receiver tab IDs, and the current listing preparation ID/status locally. Supabase authentication stays in the signed-in Invsto page. No browser cookies, passwords, payment card details, shipping addresses or private eBay API tokens are collected.

## Scan stock into an auction (1.1.3)

1. Open **Invsto · Add a stock item** on Stream Manager, then **Open Invsto receiver**. That link selects the event. In the same browser, Invsto can also detect the one open eBay event; with several open, choose one under **Change event**. On a phone, use the selected linked show, or set the destination once. The event is remembered on that device; pasting its URL is only a fallback under **Change event**.
2. In Live Sales → **Scan stock → add an auction**, set the starting bid and duration once for this event. With **Send each scan automatically** checked, scan the inventory barcode/QR and wait for **Sent** before the next scan. Event and auction settings survive a fresh visit and are stored per signed-in user and event on that device. Minimum prices and costs stay internal. Existing listing quantity checks or incomplete stock stop for review.
3. Keep the eBay stock helper open with **Prepare scans automatically** checked. It picks up each queued item and opens **Add listings → From template**. Choose a template with the correct category, condition, item specifics, shipping, and returns. The helper fills its title, description, stock photos, starting bid, and duration automatically, with one unit per listing. There are no separate Send, Prepare, or Fill clicks in this flow.
4. Review the form and click eBay's **Create listing**. This does not start the auction. After confirmation, the helper picks up the next item. If no appropriate template exists, create or correct one on eBay first. Automatic preparation pauses on a form error; use **Fill selected template** to retry after correcting it. Two helper tabs cannot prepare the same event simultaneously.
6. Invsto records the new item ID when it sees the exact title appear. If the Sold tab or a long list hides it, switch to All and find the new listing, or enter its numeric eBay item ID in the helper and click **Record created listing**. Do not create it again because confirmation is delayed.

This first release prepares one unit of a stock item per show. Duplicate scans reuse the same request. Existing online listings are not changed; verify their available quantity before offering another unit. Preparing does not reserve or deduct inventory. Continue the paid-bag scanning workflow after a sale.

Listing preparation works before, during, or after a show, without an active Invsto session. It does not start capture, create a sales session, reopen a completed show, or alter payment and bag-review status. eBay controls whether its event form accepts a listing. Keep capture linked to the correct Invsto show when you want to record payments and prepare bags.

During preparation, capture keeps reading visible payment evidence but stops changing tabs and scrolling lists. Once the listing is recorded, normal capture sweeps resume. Keep Activity visible and check captured payments against eBay. If preparation fails before submitting, close the unfinished template, release it in the helper, and retry from the phone. Once ready/submitted, inspect eBay before retrying; there is no automatic resubmission.

## Working without moving lists (1.1.1)

Capture does not reload Stream Manager. Its automatic mode scrolls the virtualized Activity and Sold lists to find payment evidence that is not currently rendered. Opening the stock-item helper or an eBay dialog now suspends that movement, including before a request is claimed. Typing, clicking, or scrolling also suspends it for fifteen seconds; focused fields remain protected.

Choose **Keep page still** to hold the lists until you click **Resume automatic capture**. This mode still records visible evidence, but does not claim complete capture readiness. Keep another Stream Manager tab in automatic capture for uninterrupted bag scanning while you work. A working or stopped tab no longer replaces the fresh health of another automatic capture tab for the same show.

Both helper panels link directly to **Open Invsto receiver**. Keep that signed-in tab open; its title identifies it as the capture receiver. The worker now tries registered receivers even when their background heartbeat timer is delayed. Reload the receiver after updating the extension.
