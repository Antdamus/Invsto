# OG Order Link Firefox — reviewer build instructions

The extension is plain JavaScript, HTML and CSS. A Python script mechanically
converts the Chromium manifest/background entry points and wraps extension API
scripts to use Firefox's Promise-based browser namespace. It does not minify,
obfuscate, bundle third-party libraries, or download dependencies.

Build environment used: Windows 11 x64, Python 3.14.2, standard library only.
The build also runs on Linux/macOS with Python 3.10 or newer. Python is available
at https://www.python.org/downloads/ or via the operating system package manager.
No Node/npm environment, credentials, API keys, or network access is needed.

From the directory containing this README, run:

    python3 tools/build-firefox-order-link-package.py --output build

On Windows, use `python` if `python3` is not installed. Output:
`build/OG-Order-Link-Firefox-unsigned.zip`.

The archive uses deterministic file metadata. Its expected SHA-256 is:
50e443361defa262262d7f223fb4a1c4b18c1e7c3e33fbc93712e15b55cbd20e

The shared source directory includes worker.js for the Chromium background list;
the Firefox build creates background.scripts and does not package worker.js.
weekly-ebay-claims.js is copied into the package as claim-export.js.

This is an internal Invsto marketplace-order integration, intended for unlisted
self-distribution. Users sign in to their own marketplace and Invsto accounts.
The configured Invsto URL receives selected order/shipping/receipt evidence.
The package contains no user sessions or credentials. Window receipt capture
uses an explicit browser chooser, checks four temporary corner markers, crops
locally, stops the stream, and requires confirmation of the cropped preview.
Only the cropped JPEG is delivered to the authenticated Invsto workspace.
